package sos.t3.a31.demo;

public class GeometryService {
	
	public double circleArea (double radius) {
		return Math.PI * radius * radius;
	}
	
}
