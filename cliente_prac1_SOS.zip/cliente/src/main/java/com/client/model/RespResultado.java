package com.client.model;

public class RespResultado {
    String resultado;

    public RespResultado() {}

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }
}
