package com.practica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaApp {
    public static void main(String[] args) {
        SpringApplication.run(PracticaApp.class, args);
    }
}