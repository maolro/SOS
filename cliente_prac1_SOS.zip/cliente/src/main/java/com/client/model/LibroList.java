package com.client.model;

public class LibroList {
    private Libro[] libroList;

    public LibroList() {}

    public Libro[] getLibroList() {
        return libroList;
    }

    public void setLibroList(Libro[] libroList) {
        this.libroList = libroList;
    }
}

