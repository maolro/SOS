package com.client.model;

public class UsuarioList {
    private Usuario[] usuarioList;

    public UsuarioList() {}

    public Usuario[] getUsuarioList() {
        return usuarioList;
    }

    public void setUsuarioList(Usuario[] usuarioList) {
        this.usuarioList = usuarioList;
    }
}
