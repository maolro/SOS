package com.client.model;

public class Href {
    private String href;

    public Href() {}

    public Href(String href) {
        this.href = href;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }
}
