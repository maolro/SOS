package com.client.model;

public class PrestamoList {
    private Prestamo[] prestamoList;

    public PrestamoList() {}

    public Prestamo[] getPrestamoList() {
        return prestamoList;
    }

    public void setLibroList(Prestamo[] prestamoList) {
        this.prestamoList = prestamoList;
    }
}
