package com.client.wrappers;

public class LibroPagedResponse {
    private EmbeddedLibro _embedded;

    public EmbeddedLibro get_embedded() {
        return _embedded;
    }

    public void set_embedded(EmbeddedLibro _embedded) {
        this._embedded = _embedded;
    }
}
